package com.yash.springiochomeassignement.springiocproblem1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springiochomeassignement.model.ConstructorMessage;
import com.yash.springiochomeassignement.model.Employee;
import com.yash.springiochomeassignement.model.PrintMessage;
import com.yash.springiochomeassignement.model.Rectangle;
import com.yash.springiochomeassignement.model.SetterMessage;

/**@author priya.gade
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
     ApplicationContext ap = new ClassPathXmlApplicationContext("Application-Context.xml"); 
    //probelm 1
   //  Employee emp = (Employee) ap.getBean("employeeBean");
            //  emp.display();
     
     
     //problem 2
    PrintMessage pm = (PrintMessage) ap.getBean("printMessageBean");
                pm.display();
    
                //problem 4
     //ConstructorMessage cm = (ConstructorMessage) ap.getBean("constructorMessageBean");
                     //   cm.display();
     
     //problem 5
    // SetterMessage sm= (SetterMessage) ap.getBean("setterMessageBean");
             //   System.out.println(  "Message is null :-  "+ sm.toString());
     
    }
}
