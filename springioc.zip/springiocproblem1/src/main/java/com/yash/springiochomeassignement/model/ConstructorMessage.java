package com.yash.springiochomeassignement.model;

public class ConstructorMessage
{
    private String message=null;

	public ConstructorMessage()
	{
		super();
	}

	public ConstructorMessage(String message)
	{
		super();
		this.message = message;
	}

	@Override
	public String toString()
	{
		return "ConstructorMessage [message=" + message + "]";
	}
    public void display()
    {
    	System.out.println("content of ConstructorMessage:- "+message);
    }
    
    
}
