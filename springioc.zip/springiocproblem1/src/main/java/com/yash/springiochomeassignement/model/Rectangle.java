package com.yash.springiochomeassignement.model;

public class Rectangle extends Shape
{

	@Override
	public void draw()
	{
	System.out.println("I am Rectangle shape");	
	}

}
