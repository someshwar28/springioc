package com.yash.springiochomeassignement.model;

public class Employee
{
  private String empId;
  private String empName;
  private String empRole;
public Employee() 
{
	super();
}
public Employee(String empId, String empName, String empRole) 
{
	super();
	this.empId = empId;
	this.empName = empName;
	this.empRole = empRole;
}
public void display()
{
	 System.out.println("-----All the details of Employee object-----");
   System.out.println("Employee Id:-      "+empId);
   System.out.println("Employee Name:-    "+empName);
   System.out.println("Employee Roll No:- "+empRole);
}
@Override
public String toString() 
{
	return "Employee [empId=" + empId + ", empName=" + empName + ", empRole=" + empRole + "]";
}
public String getEmpId() {
	return empId;
}
public void setEmpId(String empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getEmpRole() {
	return empRole;
}
public void setEmpRole(String empRole) {
	this.empRole = empRole;
}

}
