package com.yash.springiochomeassignement.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawShape 
{
   public static void main(String[] args)
   {
	   ApplicationContext apc = new ClassPathXmlApplicationContext("Application-Context.xml");
	Shape s = (Shape) apc.getBean("shapeBean");
	     s.draw();
//	     Rectangle rt =(Rectangle) apc.getBean("rectangleBean");
//	               rt.draw();
//	     Triangle tg = (Triangle) apc.getBean("triangleBean");
//	              tg.draw();
//	     Parallelogram pl = (Parallelogram) apc.getBean("parallelogramBean");
//	                   pl.draw();
//	     
   }
}
