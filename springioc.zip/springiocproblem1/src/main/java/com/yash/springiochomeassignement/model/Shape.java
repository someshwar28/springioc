package com.yash.springiochomeassignement.model;

public abstract class Shape 
{
   public abstract void draw();
}
