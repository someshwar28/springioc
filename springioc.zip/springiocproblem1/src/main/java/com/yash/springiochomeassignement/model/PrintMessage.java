package com.yash.springiochomeassignement.model;

public class PrintMessage 
{
  private String message="Yash";

public void display()
{
   System.out.println("Message:- "+ message);	
}

public String getMessage()
{
	return message;
}

public void setMessage(String message)
{
	this.message = message;
}

public PrintMessage()
{
	super();
}

public PrintMessage(String message)
{
	super();
	this.message = message;
}

@Override
public String toString() 
{
	return "PrintMessage [message=" + message + "]";
}  
}
