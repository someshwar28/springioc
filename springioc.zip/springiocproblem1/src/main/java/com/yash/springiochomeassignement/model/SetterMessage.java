package com.yash.springiochomeassignement.model;

public class SetterMessage
{
  private String message=null;

public SetterMessage()
{
	super();
}

public String getMessage() 
{
	return message;
}

public void setMessage(String message)
{
	this.message = message;
}

@Override
public String toString()
{
	return "SetterMessage [message=" + message + "]";
}

}
